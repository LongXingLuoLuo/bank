/*
#include<iostream>
using namespace std;
int m() 
{
	return 0;
}
*/